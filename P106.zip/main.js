https://teachablemachine.withgoogle.com/models/qp7ZqVpkY/
